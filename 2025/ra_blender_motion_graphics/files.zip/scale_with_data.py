import bpy
import csv

csv_file = "/data/documents/Faks/racunalna_animacija/dz1/lts.csv"
initial_frame = 100
frame_step = 30
value_step = 10
value_inst = frame_step / value_step

bars = sorted(
    [obj for obj in bpy.data.objects if "Data." in obj.name], key=lambda x: x["id"]
)
bar_locations = [bar.location.x for bar in bars]
bar_dim_z = bars[0].dimensions.z
bar_pos_z_base = bars[0].location.z

with open(csv_file, newline="") as file:
    reader = csv.reader(file)
    data = list(reader)

if len(bars) != len(data[0][1:]):
    raise ValueError("mismatch between Blender objects and CSV columns")
data = data[1:]
dates = [row[0] for row in data]


def cleanup_value(value):
    if len(value) == 0:
        return 0
    else:
        return float(value)


values = [list(map(cleanup_value, row[1:])) for row in data[1:]]
max_value = max(max(row) for row in values)

if len(values) == 0:
    raise ValueError("no rows in CSV")

label_collection = bpy.data.collections.get("GeneratedLabels")
if not label_collection:
    label_collection = bpy.data.collections.new("GeneratedLabels")
    bpy.context.scene.collection.children.link(label_collection)

value_template = bpy.data.objects.get("LabelTemplate")
date_template = bpy.data.objects.get("CurrentDateTemplate")


def show_label_between(label, start_frame, end_frame):
    label.hide_viewport = True
    label.hide_render = True
    label.keyframe_insert(data_path="hide_viewport", frame=0)
    label.keyframe_insert(data_path="hide_render", frame=0)
    label.hide_viewport = False
    label.hide_render = False
    label.keyframe_insert(data_path="hide_viewport", frame=start_frame)
    label.keyframe_insert(data_path="hide_render", frame=start_frame)
    label.hide_viewport = True
    label.hide_render = True
    label.keyframe_insert(data_path="hide_viewport", frame=end_frame)
    label.keyframe_insert(data_path="hide_render", frame=end_frame)


def lerp(begin, end, t):
    return end * t + begin * (1 - t)


def bar_z_scale(value):
    return value / max_value


def bar_z_pos(value):
    return bar_pos_z_base + (value / max_value - 1) * bar_dim_z / 2


def value_label_z_pos(value):
    return bar_z_pos(value) + ((value / max_value) * (bar_dim_z / 2.0)) + 0.2


current_frame = initial_frame
next_values = list(zip(bars, values[0]))
next_values.sort(key=lambda x: x[1])
prev_values = None
for i, row in enumerate(values):
    bar_values = next_values
    if i + 1 < len(values):
        next_values = list(zip(bars, values[i + 1]))
        next_values.sort(key=lambda x: x[1])

    curr_date = dates[i]

    date_label = date_template.copy()
    date_label.data = date_template.data.copy()
    date_label.name = f"Date_{i}"
    date_label.data.body = curr_date
    label_collection.objects.link(date_label)
    show_label_between(date_label, current_frame, current_frame + frame_step)

    for spot, (bar, value) in enumerate(bar_values):
        bar_id = bar["id"]
        bar.location.x = bar_locations[spot]

        bar.scale.z = bar_z_scale(value)
        bar.location.z = bar_z_pos(value)

        bar.keyframe_insert(data_path="scale", frame=current_frame)
        bar.keyframe_insert(data_path="location", frame=current_frame)

        next_spot, next_entry = next(
            filter(lambda it: it[1][0]["id"] == bar_id, enumerate(next_values))
        )
        label_start_x = bar_locations[spot] - (bar.scale.x * bar.dimensions.x / 2.0)
        label_end_x = bar_locations[next_spot] - (bar.scale.x * bar.dimensions.x / 2.0)
        value_z = value_label_z_pos(value)
        value_z_next = value_label_z_pos(next_entry[1])
        for j in range(0, int(frame_step / value_step)):
            delta = j / value_inst
            delta_next = min((j + 1) / value_inst, 1.0)
            inter_value = lerp(value, next_entry[1], delta)
            inter_value_next = lerp(value, next_entry[1], delta_next)

            if inter_value == 0:
                continue

            inter_start_frame = current_frame + j * value_step
            inter_end_frame = current_frame + min((j + 1) * value_step, frame_step)

            value_label = value_template.copy()
            value_label.data = value_template.data.copy()
            value_label.data.body = f"{inter_value:.2f}"
            value_label.name = f"Label_{i}_{j}_{bar_id}"
            label_collection.objects.link(value_label)

            value_label.location.z = lerp(value_z, value_z_next, delta)
            value_label.location.x = lerp(label_start_x, label_end_x, delta)
            value_label.keyframe_insert(data_path="location", frame=inter_start_frame)
            value_label.location.z = lerp(value_z, value_z_next, delta_next)
            value_label.location.x = lerp(label_start_x, label_end_x, delta_next)
            value_label.keyframe_insert(data_path="location", frame=inter_end_frame)

            show_label_between(value_label, inter_start_frame, inter_end_frame)

    prev_values = bar_values
    current_frame += frame_step

bpy.context.scene.frame_end = current_frame
