import bpy
import csv

# Configuration
csv_file = "/data/documents/Faks/racunalna_animacija/dz1/lts.csv"  # Change this to your CSV file path
frame_step = 30  # Frames per stage
start_frame = 1  # Start at this frame

# Get all bars
bars = sorted(
    [obj for obj in bpy.data.objects if "Data." in obj.name], key=lambda x: x.name
)

# Store initial x-coordinates
initial_x_coords = {bar: bar.location.x for bar in bars}

# Read CSV data
with open(csv_file, newline="") as file:
    reader = csv.reader(file)
    data = list(reader)

if len(bars) != len(data[0][1:]):
    raise ValueError("Mismatch between Blender objects and CSV columns.")

# Extract values per frame
values_per_frame = [list(map(float, row[1:])) for row in data[1:]]
dates = [row[0] for row in data[1:]]

# Compute maximum value for normalization
max_value = max(max(row) for row in values_per_frame)


# Create a collection for generated labels
label_collection = bpy.data.collections.get("GeneratedLabels")
if not label_collection:
    label_collection = bpy.data.collections.new("GeneratedLabels")
    bpy.context.scene.collection.children.link(label_collection)

series = list(zip(dates, values_per_frame))

# Animation loop
for i, (date, values) in enumerate(series):
    frame = start_frame + i * frame_step

    # Pair bars with values
    bar_data = list(map(lambda it: it[1] + (it[0],), enumerate(zip(bars, values))))

    # Sort bars by value (largest left)
    bar_data.sort(key=lambda x: x[1], reverse=False)

    # Update bars based on sorted values
    for j, (bar, value, ri) in enumerate(bar_data):
        # Assign new x position based on sorted order
        bar.location.x = list(initial_x_coords.values())[j]
        bar.keyframe_insert(data_path="location", frame=frame)

        # Scale bar height relative to max value, ensuring bottom alignment
        bar.scale.z = value / max_value  # Normalize height
        bar.location.z = (
            (bar.scale.z - 1) * bar.dimensions.z / 2
        )  # Adjust position to keep bottom fixed
        bar.keyframe_insert(data_path="scale", frame=frame)
        bar.keyframe_insert(data_path="location", frame=frame)

        # Create a new text label
        label_template = bpy.data.objects.get("LabelTemplate")
        if label_template:
            new_label = label_template.copy()
            new_label.data = label_template.data.copy()
            new_label.name = f"Label_{bar.name}_{frame}"
            label_collection.objects.link(new_label)

            # Position the label correctly on top of the bar
            new_label.location.x = bar.location.x - (
                bar.scale.x * bar.dimensions.x / 2.0
            )
            new_label.data.body = f"{value:.2f}"  # Round to 2 decimal places

            # Set visibility for the duration
            new_label.hide_viewport = False
            new_label.hide_render = False
            new_label.keyframe_insert(data_path="hide_viewport", frame=frame - 1)
            new_label.keyframe_insert(data_path="hide_render", frame=frame - 1)

            new_label.location.z = bar.location.z + (
                bar.scale.z * bar.dimensions.z / 2.0
            )
            new_label.keyframe_insert(data_path="location", frame=frame)

            new_label.hide_viewport = True
            new_label.hide_render = True
            new_label.keyframe_insert(
                data_path="hide_viewport", frame=frame + frame_step - 1
            )
            new_label.keyframe_insert(
                data_path="hide_render", frame=frame + frame_step - 1
            )

    # Create and update year label
    year_template = bpy.data.objects.get("CurrentDateTemplate")
    if year_template:
        new_year_label = year_template.copy()
        new_year_label.data = year_template.data.copy()
        new_year_label.name = f"Year_{frame}"
        label_collection.objects.link(new_year_label)

        # Position the year label in the same place as the template
        new_year_label.location = year_template.location
        new_year_label.data.body = date  # Set the text to the current date (Year/Month)

        # Set visibility for the duration
        new_year_label.hide_viewport = False
        new_year_label.hide_render = False
        new_year_label.keyframe_insert(data_path="hide_viewport", frame=frame - 1)
        new_year_label.keyframe_insert(data_path="hide_render", frame=frame - 1)
        new_year_label.hide_viewport = True
        new_year_label.hide_render = True
        new_year_label.keyframe_insert(
            data_path="hide_viewport", frame=frame + frame_step - 1
        )
        new_year_label.keyframe_insert(
            data_path="hide_render", frame=frame + frame_step - 1
        )

# Set scene frame range
bpy.context.scene.frame_start = start_frame
bpy.context.scene.frame_end = frame
